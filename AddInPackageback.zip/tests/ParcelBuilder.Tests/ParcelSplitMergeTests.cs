using System.Linq;
using ParcelBuilder.Core.Geometry;
using ParcelBuilder.Core.Models;
using Xunit;

namespace ParcelBuilder.Tests
{
    public class ParcelSplitMergeTests
    {
        [Fact]
        public void PreviewSplit_EqualSplitAlongFrontage_CalculatesTwoHalves()
        {
            var config = new BlockConfiguration();
            config.SideA.ParcelCount = 3;
            config.BaseParcel.Frontage = 20.0;
            config.BaseParcel.Depth = 30.0;
            config.Corner.HasChamfer = false;

            ParcelGeometryEngine.Instance.GenerateGeometry(config);

            var originalA2 = config.SideA.GeneratedParcels.First(p => p.Id == "A-02");
            Assert.Equal(20.0, originalA2.Frontage);
            Assert.Equal(30.0, originalA2.Depth);
            Assert.Equal(600.0, originalA2.Area);

            var (success, error, part1, part2, cutStart, cutEnd) = ParcelSplitMergeService.Instance.PreviewSplit(
                originalA2,
                SplitDirection.AlongFrontage,
                SplitPositionMode.EqualSplit,
                0.0
            );

            Assert.True(success);
            Assert.NotNull(part1);
            Assert.NotNull(part2);
            Assert.Equal(10.0, part1.Frontage);
            Assert.Equal(30.0, part1.Depth);
            Assert.Equal(300.0, part1.Area);

            Assert.Equal(10.0, part2.Frontage);
            Assert.Equal(30.0, part2.Depth);
            Assert.Equal(300.0, part2.Area);
            Assert.Equal(600.0, part1.Area + part2.Area);
        }

        [Fact]
        public void SplitParcel_EqualSplitAlongFrontage_UpdatesBlockConfiguration()
        {
            var config = new BlockConfiguration();
            config.SideA.ParcelCount = 3;
            config.BaseParcel.Frontage = 20.0;
            config.BaseParcel.Depth = 30.0;
            config.Corner.HasChamfer = false;

            ParcelGeometryEngine.Instance.GenerateGeometry(config);

            var (success, msg) = ParcelSplitMergeService.Instance.ApplySplit(
                config,
                "A-02",
                SplitDirection.AlongFrontage,
                SplitPositionMode.EqualSplit,
                0.0
            );

            Assert.True(success);
            // Side A parcel count increased from 3 to 4
            Assert.Equal(4, config.SideA.GeneratedParcels.Count);

            // Total side area and frontage remain conserved
            Assert.Equal(60.0, config.SideA.TotalFrontage);
            Assert.Equal(1800.0, config.SideA.TotalArea);
        }

        [Fact]
        public void SplitParcel_CustomSplitAlongDepth_ProducesCustomDepths()
        {
            var config = new BlockConfiguration();
            config.SideA.ParcelCount = 2;
            config.BaseParcel.Frontage = 20.0;
            config.BaseParcel.Depth = 30.0;
            config.Corner.HasChamfer = false;

            ParcelGeometryEngine.Instance.GenerateGeometry(config);

            var target = config.SideA.GeneratedParcels.First(p => p.Id == "A-01");
            var (success, error, part1, part2, _, _) = ParcelSplitMergeService.Instance.PreviewSplit(
                target,
                SplitDirection.AlongDepth,
                SplitPositionMode.CustomSplit,
                10.0 // Cut at 10m from front
            );

            Assert.True(success);
            Assert.NotNull(part1);
            Assert.NotNull(part2);

            Assert.Equal(20.0, part1.Frontage);
            Assert.Equal(10.0, part1.Depth);
            Assert.Equal(200.0, part1.Area);

            Assert.Equal(20.0, part2.Frontage);
            Assert.Equal(20.0, part2.Depth);
            Assert.Equal(400.0, part2.Area);

            Assert.Equal(600.0, part1.Area + part2.Area);
        }

        [Fact]
        public void SplitParcel_ElectricRoomFootprint_Fails()
        {
            var config = new BlockConfiguration();
            config.SideA.ParcelCount = 3;
            config.BaseParcel.Frontage = 20.0;
            config.BaseParcel.Depth = 30.0;
            config.ElectricRoom.HasElectricRoom = true;
            config.ElectricRoom.Width = 6.0;
            config.ElectricRoom.Depth = 4.0;
            config.ElectricRoom.Side = ParcelSide.SideA;
            config.ElectricRoom.OffsetDistance = 5.0;

            ParcelGeometryEngine.Instance.GenerateGeometry(config);

            var (success, msg) = ParcelSplitMergeService.Instance.ApplySplit(
                config,
                "ER-01",
                SplitDirection.AlongFrontage,
                SplitPositionMode.EqualSplit,
                0.0
            );

            Assert.False(success);
            Assert.Contains("Electric Room", msg);
        }

        [Fact]
        public void MergeParcels_AdjacentParcels_SuccessfullyMergesAndConservesArea()
        {
            var config = new BlockConfiguration();
            config.SideA.ParcelCount = 4;
            config.BaseParcel.Frontage = 20.0;
            config.BaseParcel.Depth = 30.0;
            config.Corner.HasChamfer = false;

            ParcelGeometryEngine.Instance.GenerateGeometry(config);

            var (canMerge, _) = ParcelSplitMergeService.Instance.ValidateMerge(config, "A-02", "A-03");
            Assert.True(canMerge);

            var (success, msg, merged) = ParcelSplitMergeService.Instance.MergeParcels(config, "A-02", "A-03");
            Assert.True(success);
            Assert.NotNull(merged);

            Assert.Equal(3, config.SideA.GeneratedParcels.Count);
            Assert.Equal(40.0, merged.Frontage);
            Assert.Equal(30.0, merged.Depth);
            Assert.Equal(1200.0, merged.Area); // 600 + 600 = 1200 m²
        }

        [Fact]
        public void MergeParcels_NonAdjacentParcels_FailsValidation()
        {
            var config = new BlockConfiguration();
            config.SideA.ParcelCount = 4;
            config.BaseParcel.Frontage = 20.0;
            config.BaseParcel.Depth = 30.0;
            config.Corner.HasChamfer = false;

            ParcelGeometryEngine.Instance.GenerateGeometry(config);

            // A-01 and A-04 are non-adjacent
            var (canMerge, reason) = ParcelSplitMergeService.Instance.ValidateMerge(config, "A-01", "A-04");
            Assert.False(canMerge);
            Assert.Contains("common boundary", reason);
        }

        [Fact]
        public void MergeParcels_ChamferedParcel_PreservesOuterChamfer()
        {
            var config = new BlockConfiguration();
            config.SideA.ParcelCount = 3;
            config.BaseParcel.Frontage = 20.0;
            config.BaseParcel.Depth = 30.0;
            config.Corner.HasChamfer = true;
            config.Corner.Mode = ChamferMode.StreetSetbacks;
            config.Corner.StreetASetback = 5.0;
            config.Corner.StreetBSetback = 5.0;
            config.Corner.ApplyToSideAStart = true; // A-01 has chamfer

            ParcelGeometryEngine.Instance.GenerateGeometry(config);

            var a1 = config.SideA.GeneratedParcels.First(p => p.Id == "A-01");
            Assert.Equal(5, a1.PolygonRing.Count); // 5 vertices (due to chamfer)

            var (canMerge, _) = ParcelSplitMergeService.Instance.ValidateMerge(config, "A-01", "A-02");
            Assert.True(canMerge);

            var (success, msg, merged) = ParcelSplitMergeService.Instance.MergeParcels(config, "A-01", "A-02");
            Assert.True(success);
            Assert.NotNull(merged);

            // Chamfer vertex should still be present on the outer boundary of the merged parcel
            Assert.True(merged.PolygonRing.Count >= 5);
            // Area should be exactly (600 - 12.5) + 600 = 1187.5
            Assert.Equal(1187.5, merged.Area, 1);
        }

        [Fact]
        public void MergeParcels_WithElectricRoom_FailsValidation()
        {
            var config = new BlockConfiguration();
            config.SideA.ParcelCount = 3;
            config.BaseParcel.Frontage = 20.0;
            config.BaseParcel.Depth = 30.0;
            config.ElectricRoom.HasElectricRoom = true;
            config.ElectricRoom.Width = 6.0;
            config.ElectricRoom.Depth = 4.0;
            config.ElectricRoom.Side = ParcelSide.SideA;
            config.ElectricRoom.OffsetDistance = 5.0;

            ParcelGeometryEngine.Instance.GenerateGeometry(config);

            var (canMerge, reason) = ParcelSplitMergeService.Instance.ValidateMerge(config, "A-01", "ER-01");
            Assert.False(canMerge);
            Assert.Contains("Electric Room", reason);
        }
    }
}
