using System;
using System.Collections.Generic;
using System.Linq;
using ParcelBuilder.Core.Models;

namespace ParcelBuilder.Core.Geometry
{
    /// <summary>
    /// Enterprise geometry service providing polygon Split and Merge operations,
    /// half-plane clipping, topological union, metrics recalculation, and validation.
    /// Operates strictly on in-memory models (Source data is 100% read-only).
    /// </summary>
    public class ParcelSplitMergeService
    {
        private static readonly Lazy<ParcelSplitMergeService> _instance = new(() => new ParcelSplitMergeService());
        public static ParcelSplitMergeService Instance => _instance.Value;

        private ParcelSplitMergeService() { }

        #region --- 1. SPLIT OPERATIONS ---

        /// <summary>
        /// Generates a live preview of splitting the specified parcel without mutating the configuration.
        /// </summary>
        public (bool Success, string Error, ParcelModel? Part1, ParcelModel? Part2, Point2D SplitStart, Point2D SplitEnd) PreviewSplit(
            ParcelModel parcel,
            SplitDirection direction,
            SplitPositionMode positionMode,
            double customDistance)
        {
            if (parcel == null || parcel.PolygonRing == null || parcel.PolygonRing.Count < 3)
            {
                return (false, "No valid parcel selected for split.", null, null, default, default);
            }

            var ring = parcel.PolygonRing;
            double minX = ring.Min(p => p.X);
            double maxX = ring.Max(p => p.X);
            double minY = ring.Min(p => p.Y);
            double maxY = ring.Max(p => p.Y);
            double width = maxX - minX;
            double height = maxY - minY;

            if (width < 0.01 || height < 0.01)
            {
                return (false, "Parcel geometry is degenerate or too small.", null, null, default, default);
            }

            double splitDist;
            Point2D splitStart, splitEnd;
            List<Point2D> ring1, ring2;

            if (direction == SplitDirection.AlongFrontage)
            {
                // Split divides frontage: cut line is parallel to Y-axis at X = minX + splitDist
                if (positionMode == SplitPositionMode.EqualSplit)
                {
                    splitDist = width / 2.0;
                }
                else
                {
                    if (customDistance <= 0.5 || customDistance >= width - 0.5)
                    {
                        return (false, $"Custom split distance ({customDistance:F1} m) must be between 0.5 m and {width - 0.5:F1} m.", null, null, default, default);
                    }
                    splitDist = customDistance;
                }

                double cutX = minX + splitDist;
                splitStart = new Point2D(cutX, minY);
                splitEnd = new Point2D(cutX, maxY);

                // Clip against X <= cutX (Part 1 - Left) and X >= cutX (Part 2 - Right)
                ring1 = ClipPolygonByHalfPlane(ring, p => p.X <= cutX + 1e-6, (p1, p2) => IntersectLineWithVertical(p1, p2, cutX));
                ring2 = ClipPolygonByHalfPlane(ring, p => p.X >= cutX - 1e-6, (p1, p2) => IntersectLineWithVertical(p1, p2, cutX));
            }
            else // AlongDepth
            {
                // Split divides depth: cut line is parallel to X-axis at Y = minY + splitDist
                if (positionMode == SplitPositionMode.EqualSplit)
                {
                    splitDist = height / 2.0;
                }
                else
                {
                    if (customDistance <= 0.5 || customDistance >= height - 0.5)
                    {
                        return (false, $"Custom split distance ({customDistance:F1} m) must be between 0.5 m and {height - 0.5:F1} m.", null, null, default, default);
                    }
                    splitDist = customDistance;
                }

                double cutY = minY + splitDist;
                splitStart = new Point2D(minX, cutY);
                splitEnd = new Point2D(maxX, cutY);

                // Clip against Y <= cutY (Part 1 - Front/Bottom) and Y >= cutY (Part 2 - Rear/Top)
                ring1 = ClipPolygonByHalfPlane(ring, p => p.Y <= cutY + 1e-6, (p1, p2) => IntersectLineWithHorizontal(p1, p2, cutY));
                ring2 = ClipPolygonByHalfPlane(ring, p => p.Y >= cutY - 1e-6, (p1, p2) => IntersectLineWithHorizontal(p1, p2, cutY));
            }

            ring1 = CleanPolygonRing(ring1);
            ring2 = CleanPolygonRing(ring2);

            if (ring1.Count < 3 || ring2.Count < 3)
            {
                return (false, "Split line does not produce two valid closed polygons.", null, null, default, default);
            }

            double area1 = Math.Round(ParcelGeometryEngine.ComputePolygonArea(ring1), 2);
            double area2 = Math.Round(ParcelGeometryEngine.ComputePolygonArea(ring2), 2);

            if (area1 < 1.0 || area2 < 1.0)
            {
                return (false, "Split produces a near-zero area parcel (< 1 m²).", null, null, default, default);
            }

            // Derive dimensions for parts
            double w1 = ring1.Max(p => p.X) - ring1.Min(p => p.X);
            double h1 = ring1.Max(p => p.Y) - ring1.Min(p => p.Y);
            double w2 = ring2.Max(p => p.X) - ring2.Min(p => p.X);
            double h2 = ring2.Max(p => p.Y) - ring2.Min(p => p.Y);

            var part1 = new ParcelModel
            {
                Id = $"{parcel.Id}-A",
                Side = parcel.Side,
                Sequence = parcel.Sequence,
                Frontage = Math.Round(w1, 2),
                Depth = Math.Round(h1, 2),
                Area = area1,
                IsCorner = parcel.IsCorner && (direction == SplitDirection.AlongFrontage ? true : false),
                HasChamfer = parcel.HasChamfer,
                IsModified = true,
                Type = "Split",
                PolygonRing = ring1,
                Centroid = ParcelGeometryEngine.ComputeCentroid(ring1)
            };

            var part2 = new ParcelModel
            {
                Id = $"{parcel.Id}-B",
                Side = parcel.Side,
                Sequence = parcel.Sequence + 1,
                Frontage = Math.Round(w2, 2),
                Depth = Math.Round(h2, 2),
                Area = area2,
                IsCorner = parcel.IsCorner && (direction == SplitDirection.AlongFrontage ? true : false),
                HasChamfer = parcel.HasChamfer,
                IsModified = true,
                Type = "Split",
                PolygonRing = ring2,
                Centroid = ParcelGeometryEngine.ComputeCentroid(ring2)
            };

            return (true, string.Empty, part1, part2, splitStart, splitEnd);
        }

        /// <summary>
        /// Applies the split to the active BlockConfiguration, replacing the target parcel with the two resulting parts.
        /// </summary>
        public (bool Success, string Message) ApplySplit(
            BlockConfiguration config,
            string parcelId,
            SplitDirection direction,
            SplitPositionMode positionMode,
            double customDistance)
        {
            if (config == null) return (false, "Configuration is null.");

            var targetSide = config.SideA.GeneratedParcels.Any(p => p.Id == parcelId) ? config.SideA :
                            (config.SideB.GeneratedParcels.Any(p => p.Id == parcelId) ? config.SideB : null);

            if (targetSide == null)
            {
                return (false, $"Parcel '{parcelId}' not found in current configuration.");
            }

            var originalParcel = targetSide.GeneratedParcels.FirstOrDefault(p => p.Id == parcelId);
            if (originalParcel == null)
            {
                return (false, $"Parcel '{parcelId}' not found.");
            }

            // Check Electric Room collision/relationship
            if (config.ElectricRoom != null && config.ElectricRoom.HasElectricRoom)
            {
                if (originalParcel.Id == "ER-01" || originalParcel.Type == "Electric Room")
                {
                    return (false, "Cannot split the Electric Room / Substation footprint.");
                }

                if (config.ElectricRoom.HostParcelIds.Contains(originalParcel.Id))
                {
                    // Update host parcel relationship to include the new split parcel IDs
                    config.ElectricRoom.HostParcelIds.Remove(originalParcel.Id);
                    config.ElectricRoom.HostParcelIds.Add($"{originalParcel.Id}-A");
                    config.ElectricRoom.HostParcelIds.Add($"{originalParcel.Id}-B");
                }
            }

            var (success, error, part1, part2, _, _) = PreviewSplit(originalParcel, direction, positionMode, customDistance);
            if (!success || part1 == null || part2 == null)
            {
                return (false, error);
            }

            int index = targetSide.GeneratedParcels.IndexOf(originalParcel);
            targetSide.GeneratedParcels.RemoveAt(index);
            targetSide.GeneratedParcels.Insert(index, part1);
            targetSide.GeneratedParcels.Insert(index + 1, part2);

            // Re-sequence and update IDs on the side
            RenumberSideParcels(targetSide);

            // Update block metrics
            config.SideA.TotalFrontage = config.SideA.GeneratedParcels.Sum(p => p.Frontage);
            config.SideA.TotalArea = Math.Round(config.SideA.GeneratedParcels.Sum(p => p.Area), 2);
            config.SideB.TotalFrontage = config.SideB.GeneratedParcels.Sum(p => p.Frontage);
            config.SideB.TotalArea = Math.Round(config.SideB.GeneratedParcels.Sum(p => p.Area), 2);
            config.EstimatedBlockLength = Math.Max(config.SideA.TotalFrontage, config.SideB.TotalFrontage);
            config.EstimatedBlockArea = Math.Round(config.SideA.TotalArea + config.SideB.TotalArea, 2);

            return (true, $"Parcel '{parcelId}' successfully split into '{part1.Id}' ({part1.Area:F1} m²) and '{part2.Id}' ({part2.Area:F1} m²).");
        }

        #endregion

        #region --- 2. MERGE OPERATIONS ---

        /// <summary>
        /// Validates whether two parcels can be merged.
        /// </summary>
        public (bool CanMerge, string Reason) ValidateMerge(BlockConfiguration config, string parcelIdA, string parcelIdB)
        {
            if (config == null) return (false, "Configuration is null.");
            if (string.IsNullOrEmpty(parcelIdA) || string.IsNullOrEmpty(parcelIdB))
            {
                return (false, "Please select exactly two parcels to merge.");
            }
            if (parcelIdA == parcelIdB)
            {
                return (false, "Cannot merge a parcel with itself. Please select two distinct parcels.");
            }

            var allParcels = config.SideA.GeneratedParcels.Concat(config.SideB.GeneratedParcels).ToList();
            var pA = allParcels.FirstOrDefault(p => p.Id == parcelIdA);
            var pB = allParcels.FirstOrDefault(p => p.Id == parcelIdB);

            if (pA == null || pB == null)
            {
                return (false, "One or both selected parcels were not found in the block.");
            }

            if (pA.Type == "Electric Room" || pB.Type == "Electric Room" || pA.Id == "ER-01" || pB.Id == "ER-01")
            {
                return (false, "Cannot merge with the Electric Room / Substation footprint.");
            }

            if (pA.PolygonRing.Count < 3 || pB.PolygonRing.Count < 3)
            {
                return (false, "One or both parcels have invalid polygon geometry.");
            }

            // Check if they share a common boundary
            bool sharesBoundary = CheckSharedBoundary(pA.PolygonRing, pB.PolygonRing);
            if (!sharesBoundary)
            {
                return (false, "These parcels cannot be merged because they do not share a valid common boundary.");
            }

            return (true, "Parcels share a valid common boundary and can be merged.");
        }

        /// <summary>
        /// Performs polygon union to merge two adjacent parcels into one unified parcel.
        /// </summary>
        public (bool Success, string Message, ParcelModel? MergedParcel) MergeParcels(
            BlockConfiguration config,
            string parcelIdA,
            string parcelIdB)
        {
            var (canMerge, reason) = ValidateMerge(config, parcelIdA, parcelIdB);
            if (!canMerge)
            {
                return (false, reason, null);
            }

            var allParcels = config.SideA.GeneratedParcels.Concat(config.SideB.GeneratedParcels).ToList();
            var pA = allParcels.First(p => p.Id == parcelIdA);
            var pB = allParcels.First(p => p.Id == parcelIdB);

            // Union the two polygon rings
            var unionRing = UnionAdjacentPolygonRings(pA.PolygonRing, pB.PolygonRing);
            unionRing = CleanPolygonRing(unionRing);

            if (unionRing.Count < 3)
            {
                return (false, "Union produced an invalid polygon ring.", null);
            }

            double totalArea = Math.Round(ParcelGeometryEngine.ComputePolygonArea(unionRing), 2);
            double minX = unionRing.Min(p => p.X);
            double maxX = unionRing.Max(p => p.X);
            double minY = unionRing.Min(p => p.Y);
            double maxY = unionRing.Max(p => p.Y);

            var mergedParcel = new ParcelModel
            {
                Id = $"{pA.Id}+{pB.Id.Replace("A-", "").Replace("B-", "")}",
                Side = pA.Side,
                Sequence = Math.Min(pA.Sequence, pB.Sequence),
                Frontage = Math.Round(maxX - minX, 2),
                Depth = Math.Round(maxY - minY, 2),
                Area = totalArea,
                IsCorner = pA.IsCorner || pB.IsCorner,
                HasChamfer = pA.HasChamfer || pB.HasChamfer,
                IsModified = true,
                Type = (pA.IsCorner || pB.IsCorner) ? "Corner" : "Merged",
                PolygonRing = unionRing,
                Centroid = ParcelGeometryEngine.ComputeCentroid(unionRing)
            };

            // Remove source parcels and insert merged parcel
            var side = config.SideA.GeneratedParcels.Contains(pA) ? config.SideA : config.SideB;
            int insertIndex = Math.Min(side.GeneratedParcels.IndexOf(pA), side.GeneratedParcels.IndexOf(pB));
            if (insertIndex < 0) insertIndex = 0;

            side.GeneratedParcels.Remove(pA);
            side.GeneratedParcels.Remove(pB);
            side.GeneratedParcels.Insert(insertIndex, mergedParcel);

            // Update Electric Room host associations if needed
            if (config.ElectricRoom != null && config.ElectricRoom.HasElectricRoom)
            {
                if (config.ElectricRoom.HostParcelIds.Contains(parcelIdA) || config.ElectricRoom.HostParcelIds.Contains(parcelIdB))
                {
                    config.ElectricRoom.HostParcelIds.Remove(parcelIdA);
                    config.ElectricRoom.HostParcelIds.Remove(parcelIdB);
                    config.ElectricRoom.HostParcelIds.Add(mergedParcel.Id);
                }
            }

            RenumberSideParcels(side);

            // Update block metrics
            config.SideA.TotalFrontage = config.SideA.GeneratedParcels.Sum(p => p.Frontage);
            config.SideA.TotalArea = Math.Round(config.SideA.GeneratedParcels.Sum(p => p.Area), 2);
            config.SideB.TotalFrontage = config.SideB.GeneratedParcels.Sum(p => p.Frontage);
            config.SideB.TotalArea = Math.Round(config.SideB.GeneratedParcels.Sum(p => p.Area), 2);
            config.EstimatedBlockLength = Math.Max(config.SideA.TotalFrontage, config.SideB.TotalFrontage);
            config.EstimatedBlockArea = Math.Round(config.SideA.TotalArea + config.SideB.TotalArea, 2);

            return (true, $"Parcels '{parcelIdA}' and '{parcelIdB}' successfully merged into '{mergedParcel.Id}' (Total Area: {totalArea:F1} m²).", mergedParcel);
        }

        #endregion

        #region --- 3. GEOMETRY HELPER METHODS ---

        /// <summary>
        /// Sutherland-Hodgman clipping of a polygon against an arbitrary half-plane.
        /// </summary>
        private static List<Point2D> ClipPolygonByHalfPlane(
            List<Point2D> ring,
            Func<Point2D, bool> isInside,
            Func<Point2D, Point2D, Point2D> computeIntersection)
        {
            var outputList = new List<Point2D>();
            if (ring.Count == 0) return outputList;

            Point2D s = ring[^1];

            foreach (var e in ring)
            {
                if (isInside(e))
                {
                    if (isInside(s))
                    {
                        outputList.Add(e);
                    }
                    else
                    {
                        outputList.Add(computeIntersection(s, e));
                        outputList.Add(e);
                    }
                }
                else if (isInside(s))
                {
                    outputList.Add(computeIntersection(s, e));
                }
                s = e;
            }

            return outputList;
        }

        private static Point2D IntersectLineWithVertical(Point2D p1, Point2D p2, double x)
        {
            double dx = p2.X - p1.X;
            if (Math.Abs(dx) < 1e-9) return new Point2D(x, p1.Y);
            double t = (x - p1.X) / dx;
            double y = p1.Y + t * (p2.Y - p1.Y);
            return new Point2D(x, y);
        }

        private static Point2D IntersectLineWithHorizontal(Point2D p1, Point2D p2, double y)
        {
            double dy = p2.Y - p1.Y;
            if (Math.Abs(dy) < 1e-9) return new Point2D(p1.X, y);
            double t = (y - p1.Y) / dy;
            double x = p1.X + t * (p2.X - p1.X);
            return new Point2D(x, y);
        }

        /// <summary>
        /// Checks whether two polygon rings share a common edge or overlapping boundary segment.
        /// </summary>
        public static bool CheckSharedBoundary(List<Point2D> ringA, List<Point2D> ringB)
        {
            int sharedPoints = 0;
            for (int i = 0; i < ringA.Count; i++)
            {
                var ptA = ringA[i];
                for (int j = 0; j < ringB.Count; j++)
                {
                    var ptB = ringB[j];
                    if (Math.Abs(ptA.X - ptB.X) < 0.05 && Math.Abs(ptA.Y - ptB.Y) < 0.05)
                    {
                        sharedPoints++;
                        break;
                    }
                }
            }

            if (sharedPoints >= 2) return true;

            // Also check if any edge of A overlaps collinear with an edge of B
            for (int i = 0; i < ringA.Count; i++)
            {
                var a1 = ringA[i];
                var a2 = ringA[(i + 1) % ringA.Count];

                for (int j = 0; j < ringB.Count; j++)
                {
                    var b1 = ringB[j];
                    var b2 = ringB[(j + 1) % ringB.Count];

                    if (SegmentsCollinearAndOverlap(a1, a2, b1, b2))
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        private static bool SegmentsCollinearAndOverlap(Point2D a1, Point2D a2, Point2D b1, Point2D b2)
        {
            // Check vertical collinearity
            if (Math.Abs(a1.X - a2.X) < 0.05 && Math.Abs(b1.X - b2.X) < 0.05 && Math.Abs(a1.X - b1.X) < 0.05)
            {
                double minA = Math.Min(a1.Y, a2.Y), maxA = Math.Max(a1.Y, a2.Y);
                double minB = Math.Min(b1.Y, b2.Y), maxB = Math.Max(b1.Y, b2.Y);
                return Math.Max(minA, minB) < Math.Min(maxA, maxB) - 0.05;
            }

            // Check horizontal collinearity
            if (Math.Abs(a1.Y - a2.Y) < 0.05 && Math.Abs(b1.Y - b2.Y) < 0.05 && Math.Abs(a1.Y - b1.Y) < 0.05)
            {
                double minA = Math.Min(a1.X, a2.X), maxA = Math.Max(a1.X, a2.X);
                double minB = Math.Min(b1.X, b2.X), maxB = Math.Max(b1.X, b2.X);
                return Math.Max(minA, minB) < Math.Min(maxA, maxB) - 0.05;
            }

            return false;
        }

        /// <summary>
        /// Unions two adjacent polygon rings that share an edge or interface into one single outer perimeter polygon,
        /// properly preserving corner chamfers, setbacks, and irregular outer vertices.
        /// </summary>
        public static List<Point2D> UnionAdjacentPolygonRings(List<Point2D> ringA, List<Point2D> ringB)
        {
            if (ringA == null || ringA.Count < 3) return ringB ?? new List<Point2D>();
            if (ringB == null || ringB.Count < 3) return ringA ?? new List<Point2D>();

            try
            {
                // Deconstruct rings into directed segments
                var segmentsA = GetDirectedSegments(ringA);
                var segmentsB = GetDirectedSegments(ringB);

                var outerSegments = new List<(Point2D Start, Point2D End)>();

                // Keep segments of A not shared/overlapping in B
                foreach (var segA in segmentsA)
                {
                    if (!IsSegmentShared(segA.Start, segA.End, segmentsB))
                    {
                        outerSegments.Add(segA);
                    }
                }

                // Keep segments of B not shared/overlapping in A
                foreach (var segB in segmentsB)
                {
                    if (!IsSegmentShared(segB.Start, segB.End, segmentsA))
                    {
                        outerSegments.Add(segB);
                    }
                }

                if (outerSegments.Count >= 3)
                {
                    // Chain outer segments into a single closed ring
                    var chainedRing = ChainSegmentsIntoRing(outerSegments);
                    if (chainedRing != null && chainedRing.Count >= 3)
                    {
                        return CleanPolygonRing(chainedRing);
                    }
                }
            }
            catch
            {
                // Fallback to bounding geometry if stitching fails
            }

            // Fallback: construct bounding box polygon
            double minX = Math.Min(ringA.Min(p => p.X), ringB.Min(p => p.X));
            double maxX = Math.Max(ringA.Max(p => p.X), ringB.Max(p => p.X));
            double minY = Math.Min(ringA.Min(p => p.Y), ringB.Min(p => p.Y));
            double maxY = Math.Max(ringA.Max(p => p.Y), ringB.Max(p => p.Y));

            return new List<Point2D>
            {
                new Point2D(minX, minY),
                new Point2D(maxX, minY),
                new Point2D(maxX, maxY),
                new Point2D(minX, maxY)
            };
        }

        private static List<(Point2D Start, Point2D End)> GetDirectedSegments(List<Point2D> ring)
        {
            var segments = new List<(Point2D Start, Point2D End)>();
            for (int i = 0; i < ring.Count; i++)
            {
                var p1 = ring[i];
                var p2 = ring[(i + 1) % ring.Count];
                if (Math.Abs(p1.X - p2.X) > 1e-4 || Math.Abs(p1.Y - p2.Y) > 1e-4)
                {
                    segments.Add((p1, p2));
                }
            }
            return segments;
        }

        private static bool IsSegmentShared(Point2D s1, Point2D s2, List<(Point2D Start, Point2D End)> otherSegments)
        {
            foreach (var (o1, o2) in otherSegments)
            {
                // Exact opposite match
                if (PointsEqual(s1, o2) && PointsEqual(s2, o1))
                    return true;

                // Collinear and overlapping segment on interior boundary
                if (SegmentsCollinearAndOverlap(s1, s2, o1, o2))
                    return true;
            }
            return false;
        }

        private static bool PointsEqual(Point2D a, Point2D b, double tol = 0.05)
        {
            return Math.Abs(a.X - b.X) <= tol && Math.Abs(a.Y - b.Y) <= tol;
        }

        private static List<Point2D>? ChainSegmentsIntoRing(List<(Point2D Start, Point2D End)> segments)
        {
            if (segments.Count == 0) return null;

            var remaining = new List<(Point2D Start, Point2D End)>(segments);
            var result = new List<Point2D>();

            var current = remaining[0];
            result.Add(current.Start);
            remaining.RemoveAt(0);
            var currentEnd = current.End;

            int iterations = 0;
            int maxIterations = segments.Count * 3;

            while (remaining.Count > 0 && iterations++ < maxIterations)
            {
                result.Add(currentEnd);

                int nextIdx = -1;
                for (int i = 0; i < remaining.Count; i++)
                {
                    if (PointsEqual(remaining[i].Start, currentEnd))
                    {
                        nextIdx = i;
                        currentEnd = remaining[i].End;
                        break;
                    }
                    if (PointsEqual(remaining[i].End, currentEnd))
                    {
                        nextIdx = i;
                        currentEnd = remaining[i].Start;
                        break;
                    }
                }

                if (nextIdx >= 0)
                {
                    remaining.RemoveAt(nextIdx);
                    if (PointsEqual(currentEnd, result[0]))
                    {
                        break;
                    }
                }
                else
                {
                    break;
                }
            }

            return result.Count >= 3 ? result : null;
        }

        /// <summary>
        /// Cleans a polygon ring by removing duplicate adjacent points and collinear vertices.
        /// </summary>
        public static List<Point2D> CleanPolygonRing(List<Point2D> ring)
        {
            if (ring == null || ring.Count < 3) return ring ?? new List<Point2D>();

            var clean = new List<Point2D>();
            for (int i = 0; i < ring.Count; i++)
            {
                var pt = ring[i];
                if (clean.Count == 0 || Math.Abs(clean[^1].X - pt.X) > 0.01 || Math.Abs(clean[^1].Y - pt.Y) > 0.01)
                {
                    clean.Add(pt);
                }
            }

            // Ensure first and last are not duplicate
            if (clean.Count > 1 && Math.Abs(clean[0].X - clean[^1].X) < 0.01 && Math.Abs(clean[0].Y - clean[^1].Y) < 0.01)
            {
                clean.RemoveAt(clean.Count - 1);
            }

            if (clean.Count < 3) return clean;

            // Remove collinear points
            var simplified = new List<Point2D>();
            for (int i = 0; i < clean.Count; i++)
            {
                var prev = clean[(i - 1 + clean.Count) % clean.Count];
                var curr = clean[i];
                var next = clean[(i + 1) % clean.Count];

                // Cross product to check collinearity
                double cross = (curr.X - prev.X) * (next.Y - prev.Y) - (curr.Y - prev.Y) * (next.X - prev.X);
                if (Math.Abs(cross) > 1e-4)
                {
                    simplified.Add(curr);
                }
            }

            return simplified.Count >= 3 ? simplified : clean;
        }

        private static void RenumberSideParcels(SideConfiguration side)
        {
            string prefix = side.Side == ParcelSide.SideA ? "A" : "B";
            for (int i = 0; i < side.GeneratedParcels.Count; i++)
            {
                var parcel = side.GeneratedParcels[i];
                parcel.Sequence = i + 1;
                // Maintain clean identity
                if (!parcel.Id.Contains("-A") && !parcel.Id.Contains("-B") && !parcel.Id.Contains("+") && parcel.Id != "ER-01")
                {
                    parcel.Id = $"{prefix}-{parcel.Sequence:D2}";
                }
            }
            side.ParcelCount = side.GeneratedParcels.Count;
        }

        #endregion
    }
}
