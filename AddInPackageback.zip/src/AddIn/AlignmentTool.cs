using System;
using System.Linq;
using System.Threading.Tasks;
using ArcGIS.Core.Geometry;
using ArcGIS.Desktop.Framework;
using ArcGIS.Desktop.Framework.Threading.Tasks;
using ArcGIS.Desktop.Mapping;

namespace ParcelBuilder.AddIn
{
    /// <summary>
    /// Interactive map tool allowing user to draw a 2-point orientation line on the map with active snapping
    /// to define the block orientation baseline vector (P1 -> P2) without moving the Base Point anchor.
    /// </summary>
    internal class AlignmentTool : MapTool
    {
        public AlignmentTool()
        {
            IsSketchTool = true;
            SketchType = SketchGeometryType.Line;
            SketchOutputMode = SketchOutputMode.Map;
            UseSnapping = true;
        }

        protected override Task OnToolActivateAsync(bool hasMapViewChanged)
        {
            var dockPane = FrameworkApplication.DockPaneManager.Find("ParcelBuilder_DockPane") as ParcelBuilderDockPaneViewModel;
            if (dockPane != null)
            {
                dockPane.StatusText = "📍 Click Point 1 (P1) then Point 2 (P2) on the map (with snapping) to define orientation baseline...";
            }
            return Task.CompletedTask;
        }

        protected override async Task<bool> OnSketchCompleteAsync(Geometry geometry)
        {
            if (geometry is not Polyline polyline) return false;

            var dockPane = FrameworkApplication.DockPaneManager.Find("ParcelBuilder_DockPane") as ParcelBuilderDockPaneViewModel;

            try
            {
                double x1 = 0, y1 = 0, x2 = 0, y2 = 0;
                bool valid = false;

                await QueuedTask.Run(() =>
                {
                    var mapView = MapView.Active;
                    var mapSr = mapView?.Map?.SpatialReference ?? geometry.SpatialReference ?? SpatialReferences.WGS84;
                    var projectedPoly = GeometryEngine.Instance.Project(polyline, mapSr) as Polyline ?? polyline;

                    var pts = projectedPoly.Points;
                    if (pts != null && pts.Count >= 2)
                    {
                        var p1 = pts.First();
                        var p2 = pts.Last();
                        x1 = p1.X;
                        y1 = p1.Y;
                        x2 = p2.X;
                        y2 = p2.Y;
                        valid = true;
                    }
                });

                if (valid && dockPane != null)
                {
                    dockPane.Activate();
                    dockPane.SetOrientationTwoPoints(x1, y1, x2, y2);
                }
            }
            catch (Exception ex)
            {
                if (dockPane != null)
                {
                    dockPane.StatusText = $"Orientation notice: {ex.Message}";
                }
            }

            return true;
        }
    }
}
